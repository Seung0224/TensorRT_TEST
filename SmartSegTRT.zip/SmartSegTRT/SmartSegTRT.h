#pragma once
// SmartSegTRT.h
#pragma once

#ifdef SMARTSEGTRT_EXPORTS
#define SMARTSEG_API extern "C" __declspec(dllexport)
#else
#define SMARTSEG_API extern "C" __declspec(dllimport)
#endif

// C API (�ּ� ��Ʈ)
SMARTSEG_API void* SmartSegCreate(const char* enginePath);
SMARTSEG_API void  SmartSegDestroy(void* handle);

// I/O info
SMARTSEG_API int  SmartSegGetNbIOTensors(void* handle);                                 // ����
SMARTSEG_API int  SmartSegGetTensorName(void* handle, int index, char* out, int max);   // �̸�
SMARTSEG_API int  SmartSegIsInput(void* handle, int index);                             // 1=input, 0=output, <0 error
SMARTSEG_API int  SmartSegGetTensorDims(void* handle, int index, int* dims, int max);   // ��ȯ: ndim, dims[0..ndim-1]
SMARTSEG_API int SmartSegInfer(void* handle,
    const unsigned char* bgr, int w, int h, int strideBytes);

// ��� �ټ�(OUTPUT��) ����/����/������ ��ȸ
SMARTSEG_API int  SmartSegGetNumOutputs(void* handle);                                   // OUTPUT ����
SMARTSEG_API int  SmartSegGetOutputName(void* handle, int outIndex, char* out, int max); // �̸�
SMARTSEG_API int  SmartSegGetOutputDims(void* handle, int outIndex, int* dims, int max); // ��ȯ: ndim
SMARTSEG_API int  SmartSegGetOutputFloat(void* handle, int outIndex, float* dst, int maxFloats); // ��ȯ: ������ ����

// === Decode & Query API ===
SMARTSEG_API int   SmartSegDecode(void* handle, float confThres, float iouThres, int topK); // ��ȯ: det ����
SMARTSEG_API int   SmartSegGetNumDetections(void* handle);                                  // det ����
SMARTSEG_API int   SmartSegGetDetBox(void* handle, int idx, float* xyxy4);                  // [x1,y1,x2,y2]
SMARTSEG_API float SmartSegGetDetScore(void* handle, int idx);                              // score
SMARTSEG_API int   SmartSegGetDetClass(void* handle, int idx);                              // class id
SMARTSEG_API int   SmartSegGetDetMask(void* handle, int idx,
    unsigned char* dst, int outW, int outH, int dstStride, float thresh);
