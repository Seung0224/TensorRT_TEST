﻿// SmartSegTRT.cpp
#include "SmartSegTRT.h"

#include <NvInfer.h>
#include <NvInferRuntime.h>
#include <cuda_runtime_api.h>

#include <cstdio>
#include <memory>
#include <vector>
#include <fstream>
#include <string>
#include <NvInferVersion.h>  // NV_TENSORRT_MAJOR 사용

#include <cstring>
#include <algorithm>
#include <array>
#include <cmath>
#include <numeric>

#if NV_TENSORRT_MAJOR >= 10
#define TRT_SAFE_DESTROY(p) do { if (p) { delete (p); (p) = nullptr; } } while(0)
#else
#define TRT_SAFE_DESTROY(p) do { if (p) { (p)->destroy(); (p) = nullptr; } } while(0)
#endif



// ===== Logger =====
class TrtLogger : public nvinfer1::ILogger {
public:
    void log(Severity s, const char* msg) noexcept override {
        // 필요한 수준만 출력
        if (s <= Severity::kWARNING) {
            std::printf("[TRT] %s\n", msg);
        }
    }
};

struct Det {
    std::array<float, 4> xyxy;   // x1,y1,x2,y2 (입력 해상도 640 기준)
    float score = 0.f;
    int   cls = 0;
    std::array<float, 32> coeff{};
};

struct HostTensor {
    std::string name;
    nvinfer1::Dims dims{};
    std::vector<float> data; // FP32 가정
};

struct TrtHandle {
    TrtLogger logger;
    nvinfer1::IRuntime* runtime = nullptr;
    nvinfer1::ICudaEngine* engine = nullptr;
    nvinfer1::IExecutionContext* context = nullptr;
    cudaStream_t stream = nullptr;

    std::vector<HostTensor> lastOutputs; // ← 마지막 추론 결과
    std::vector<Det>        lastDetections;

    ~TrtHandle() {
        if (stream) { cudaStreamDestroy(stream); stream = nullptr; }
#if NV_TENSORRT_MAJOR >= 10
        if (context) { delete context; context = nullptr; }
        if (engine) { delete engine;  engine = nullptr; }
        if (runtime) { delete runtime; runtime = nullptr; }
#else
        if (context) { context->destroy(); context = nullptr; }
        if (engine) { engine->destroy();  engine = nullptr; }
        if (runtime) { runtime->destroy(); runtime = nullptr; }
#endif
    }
};

// ===== 유틸: 파일 읽기 =====
static std::vector<char> readFile(const char* path) {
    if (!path) return {};
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) return {};
    std::streamsize size = f.tellg();
    f.seekg(0, std::ios::beg);
    std::vector<char> buf(static_cast<size_t>(size));
    if (!f.read(buf.data(), size)) return {};
    return buf;
}

// 안전 sigmoid
static inline float sigmoidf(float x) {
    return 1.f / (1.f + std::exp(-x));
}

// IoU
static inline float iou_xyxy(const float a[4], const float b[4]) {
    float ax1 = a[0], ay1 = a[1], ax2 = a[2], ay2 = a[3];
    float bx1 = b[0], by1 = b[1], bx2 = b[2], by2 = b[3];
    float iw = std::max(0.f, std::min(ax2, bx2) - std::max(ax1, bx1));
    float ih = std::max(0.f, std::min(ay2, by2) - std::max(ay1, by1));
    float inter = iw * ih;
    float aarea = std::max(0.f, ax2 - ax1) * std::max(0.f, ay2 - ay1);
    float barea = std::max(0.f, bx2 - bx1) * std::max(0.f, by2 - by1);
    float uni = aarea + barea - inter;
    return (uni <= 0.f) ? 0.f : (inter / uni);
}

// 간단 NMS (score 내림차순 후보에서 IoU>thres 제거)
static void nms(std::vector<int>& keep,
    const std::vector<std::array<float, 4>>& boxes,
    const std::vector<float>& scores,
    float iouThres, int topK)
{
    std::vector<int> order(boxes.size());
    std::iota(order.begin(), order.end(), 0);
    std::sort(order.begin(), order.end(),
        [&](int a, int b) { return scores[a] > scores[b]; });

    for (int i : order)   // ← 변수 이름 필수
    {
        bool sup = false;
        float bi[4] = { boxes[i][0], boxes[i][1], boxes[i][2], boxes[i][3] };
        for (int k : keep)
        {
            float bk[4] = { boxes[k][0], boxes[k][1], boxes[k][2], boxes[k][3] };
            if (iou_xyxy(bi, bk) > iouThres) { sup = true; break; }
        }
        if (!sup) {
            keep.push_back(i);
            if (topK > 0 && (int)keep.size() >= topK) break;
        }
    }
}

// 160->任의크기 bilinear 업샘플 (src: HxW [0..1], dst: outH x outW)
static void upsample_bilinear(const float* src, int W, int H, float* dst, int outW, int outH)
{
    const float scaleX = (float)W / (float)outW;
    const float scaleY = (float)H / (float)outH;
    for (int y = 0; y < outH; ++y) {
        float fy = (y + 0.5f) * scaleY - 0.5f;
        int y0 = (int)std::floor(fy);
        int y1 = std::min(y0 + 1, H - 1);
        float ly = fy - y0; if (y0 < 0) { y0 = 0; ly = 0; }
        for (int x = 0; x < outW; ++x) {
            float fx = (x + 0.5f) * scaleX - 0.5f;
            int x0 = (int)std::floor(fx);
            int x1 = std::min(x0 + 1, W - 1);
            float lx = fx - x0; if (x0 < 0) { x0 = 0; lx = 0; }
            float v00 = src[y0 * W + x0];
            float v01 = src[y0 * W + x1];
            float v10 = src[y1 * W + x0];
            float v11 = src[y1 * W + x1];
            float v0 = v00 + (v01 - v00) * lx;
            float v1 = v10 + (v11 - v10) * lx;
            dst[y * outW + x] = v0 + (v1 - v0) * ly;
        }
    }
}

SMARTSEG_API int SmartSegGetNumDetections(void* handle)
{
    if (!handle) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    return (int)h->lastDetections.size();
}

SMARTSEG_API int SmartSegGetDetBox(void* handle, int idx, float* xyxy4)
{
    if (!handle || !xyxy4) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (idx < 0 || idx >= (int)h->lastDetections.size()) return -2;
    const auto& d = h->lastDetections[idx];
    xyxy4[0] = d.xyxy[0]; xyxy4[1] = d.xyxy[1];
    xyxy4[2] = d.xyxy[2]; xyxy4[3] = d.xyxy[3];
    return 0;
}

SMARTSEG_API float SmartSegGetDetScore(void* handle, int idx)
{
    if (!handle) return -1.f;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (idx < 0 || idx >= (int)h->lastDetections.size()) return -2.f;
    return h->lastDetections[idx].score;
}

SMARTSEG_API int SmartSegGetDetClass(void* handle, int idx)
{
    if (!handle) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (idx < 0 || idx >= (int)h->lastDetections.size()) return -2;
    return h->lastDetections[idx].cls;
}

SMARTSEG_API int SmartSegGetDetMask(void* handle, int idx,
    unsigned char* dst, int outW, int outH, int dstStride, float thresh)
{
    if (!handle || !dst || outW <= 0 || outH <= 0 || dstStride < outW) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (idx < 0 || idx >= (int)h->lastDetections.size()) return -2;

    // 프로토 찾기
    int pIndex = -1;
    for (int i = 0; i < (int)h->lastOutputs.size(); ++i) {
        const auto& t = h->lastOutputs[i];
        if (t.dims.nbDims == 4 && t.dims.d[0] == 1 && t.dims.d[1] == 32 && t.dims.d[2] == 160 && t.dims.d[3] == 160) {
            pIndex = i; break;
        }
    }
    if (pIndex < 0) return -3;

    const auto& proto = h->lastOutputs[pIndex];
    const float* P = proto.data.data(); // NCHW (1,32,160,160)
    const int C = 32, H = 160, W = 160;

    // 1) coeff · proto → mask160 (float)
    std::vector<float> mask160(W * H, 0.f);
    const auto& cf = h->lastDetections[idx].coeff;

    for (int c = 0; c < C; ++c) {
        const float* pc = P + c * (W * H);
        float alpha = cf[c];
        for (int i = 0; i < W * H; ++i) mask160[i] += alpha * pc[i];
    }
    // sigmoid
    for (int i = 0; i < W * H; ++i) mask160[i] = sigmoidf(mask160[i]);

    // 2) 업샘플 160→outW×outH
    std::vector<float> maskHi(outW * outH);
    upsample_bilinear(mask160.data(), W, H, maskHi.data(), outW, outH);

    // 3) bbox 영역만 남기기(선택: 바깥 0)
    const auto& d = h->lastDetections[idx];
    int x1 = std::max(0, (int)std::floor(d.xyxy[0] * outW / 640.f));
    int y1 = std::max(0, (int)std::floor(d.xyxy[1] * outH / 640.f));
    int x2 = std::min(outW, (int)std::ceil(d.xyxy[2] * outW / 640.f));
    int y2 = std::min(outH, (int)std::ceil(d.xyxy[3] * outH / 640.f));

    // 4) threshold 및 복사
    for (int y = 0; y < outH; ++y) {
        unsigned char* row = dst + y * dstStride;
        for (int x = 0; x < outW; ++x) {
            float v = maskHi[y * outW + x];
            // bbox 밖은 0
            if (x < x1 || x >= x2 || y < y1 || y >= y2) v = 0.f;
            row[x] = (v >= thresh) ? 255 : 0;
        }
    }
    return 0;
}


SMARTSEG_API int SmartSegDecode(void* handle, float confThres, float iouThres, int topK)
{
    if (!handle) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (h->lastOutputs.empty()) return -2;

    // output0: (1, 37, 8400), output1: (1, 32, 160, 160)
    int idx0 = -1, idx1 = -1;
    for (int i = 0; i < (int)h->lastOutputs.size(); ++i) {
        const auto& t = h->lastOutputs[i];
        if (t.dims.nbDims == 3 && t.dims.d[0] == 1 && t.dims.d[1] == 37) idx0 = i;
        if (t.dims.nbDims == 4 && t.dims.d[0] == 1 && t.dims.d[1] == 32 && t.dims.d[2] == 160 && t.dims.d[3] == 160) idx1 = i;
    }
    if (idx0 < 0 || idx1 < 0) return -3;

    const auto& pred = h->lastOutputs[idx0]; // (1, 37, 8400) = [xywh(4), cls(1), coeff(32)]
    const auto& proto = h->lastOutputs[idx1]; // (1, 32, 160, 160)

    const int C = pred.dims.d[1]; // 37
    const int N = pred.dims.d[2]; // 8400
    const float* P = pred.data.data();

    auto at = [&](int c, int i)->float { return P[c * N + i]; }; // (C,N) 메모리

    // YOLOv8 grid/stride (640 입력 기준): 80x80@s8, 40x40@s16, 20x20@s32
    constexpr int G0 = 80, G1 = 40, G2 = 20;
    constexpr int S0 = 8, S1 = 16, S2 = 32;
    constexpr int N0 = G0 * G0;       // 6400
    constexpr int N1 = G1 * G1;       // 1600
    constexpr int N2 = G2 * G2;       // 400

    std::vector<std::array<float, 4>> boxes;
    std::vector<float> scores;
    std::vector<std::array<float, 32>> coeffs;
    boxes.reserve(N);
    scores.reserve(N);
    coeffs.reserve(N);

    for (int i = 0; i < N; ++i)
    {
        int j = i, gx = 0, gy = 0, stride = 0, gw = 0;
        if (j < N0) { stride = S0; gw = G0; gy = j / gw; gx = j % gw; }
        else if ((j -= N0) < N1) { stride = S1; gw = G1; gy = j / gw; gx = j % gw; }
        else { j -= N1;          stride = S2; gw = G2; gy = j / gw; gx = j % gw; }

        // raw → decode (ultralytics 공식 yolo v8 식)
        float px = at(0, i), py = at(1, i), pw = at(2, i), ph = at(3, i);
        float x = (sigmoidf(px) * 2.f - 0.5f + gx) * (float)stride;
        float y = (sigmoidf(py) * 2.f - 0.5f + gy) * (float)stride;
        float w = std::pow(sigmoidf(pw) * 2.f, 2.f) * (float)stride;
        float h = std::pow(sigmoidf(ph) * 2.f, 2.f) * (float)stride;

        float sc = sigmoidf(at(4, i)); // 단일 클래스 가정
        if (sc < confThres) continue;

        float x1 = std::clamp(x - w * 0.5f, 0.f, 640.f);
        float y1 = std::clamp(y - h * 0.5f, 0.f, 640.f);
        float x2 = std::clamp(x + w * 0.5f, 0.f, 640.f);
        float y2 = std::clamp(y + h * 0.5f, 0.f, 640.f);

        std::array<float, 32> cf{};
        for (int k = 0; k < 32; ++k) cf[k] = at(5 + k, i);

        boxes.push_back({ x1,y1,x2,y2 });
        scores.push_back(sc);
        coeffs.push_back(cf);
    }

    // NMS
    std::vector<int> keep;
    nms(keep, boxes, scores, iouThres, topK);

    // 저장
    h->lastDetections.clear();
    h->lastDetections.reserve(keep.size());
    for (int id : keep) {
        Det d;
        d.xyxy = boxes[id];
        d.score = scores[id];
        d.cls = 0;
        d.coeff = coeffs[id];
        h->lastDetections.emplace_back(std::move(d));
    }
    return (int)h->lastDetections.size();
}





// ===== C API 구현 =====
SMARTSEG_API void* SmartSegCreate(const char* enginePath)
{
    std::printf("[SmartSegTRT] SmartSegCreate(%s)\n", enginePath ? enginePath : "(null)");
    if (!enginePath) {
        std::printf("[SmartSegTRT] ERROR: enginePath is null\n");
        return nullptr;
    }

    auto bytes = readFile(enginePath);
    if (bytes.empty()) {
        std::printf("[SmartSegTRT] ERROR: failed to read engine file\n");
        return nullptr;
    }

    // 핸들 준비
    std::unique_ptr<TrtHandle> h(new TrtHandle());

    // runtime
    h->runtime = nvinfer1::createInferRuntime(h->logger);
    if (!h->runtime) {
        std::printf("[SmartSegTRT] ERROR: createInferRuntime failed\n");
        return nullptr;
    }

    // engine
    h->engine = h->runtime->deserializeCudaEngine(bytes.data(), bytes.size());
    if (!h->engine) {
        std::printf("[SmartSegTRT] ERROR: deserializeCudaEngine failed\n");
        return nullptr;
    }

    // context
    h->context = h->engine->createExecutionContext();
    if (!h->context) {
        std::printf("[SmartSegTRT] ERROR: createExecutionContext failed\n");
        return nullptr;
    }

    // stream
    auto st = cudaStreamCreate(&h->stream);
    if (st != cudaSuccess) {
        std::printf("[SmartSegTRT] ERROR: cudaStreamCreate failed (%d)\n", (int)st);
        return nullptr;
    }

    std::printf("[SmartSegTRT] READY: NbIOTensors=%d\n",
        (int)h->engine->getNbIOTensors());

    // 성공 시 소유권 이전
    return h.release();
}

SMARTSEG_API void SmartSegDestroy(void* handle)
{
    std::printf("[SmartSegTRT] SmartSegDestroy\n");
    if (!handle) return;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    delete h; // ~TrtHandle에서 destroy()/cudaStreamDestroy() 호출됨
}

static const char* _getNameByIndex(nvinfer1::ICudaEngine* e, int index) {
#if NV_TENSORRT_MAJOR >= 10
    return e->getIOTensorName(index);
#else
    return e->getBindingName(index);
#endif
}

SMARTSEG_API int SmartSegGetNbIOTensors(void* handle)
{
    if (!handle) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (!h->engine) return -2;
#if NV_TENSORRT_MAJOR >= 10
    return static_cast<int>(h->engine->getNbIOTensors());
#else
    return static_cast<int>(h->engine->getNbBindings());
#endif
}

SMARTSEG_API int SmartSegGetTensorName(void* handle, int index, char* out, int max)
{
    if (!handle || !out || max <= 0) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (!h->engine) return -2;

    int n =
#if NV_TENSORRT_MAJOR >= 10
        static_cast<int>(h->engine->getNbIOTensors());
#else
        static_cast<int>(h->engine->getNbBindings());
#endif
    if (index < 0 || index >= n) return -3;

    const char* name = _getNameByIndex(h->engine, index);
    if (!name) return -4;

    int len = static_cast<int>(std::strlen(name));
    if (len + 1 > max) len = max - 1;
    std::memcpy(out, name, len);
    out[len] = '\0';
    return len; // 복사된 길이
}

SMARTSEG_API int SmartSegIsInput(void* handle, int index)
{
    if (!handle) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (!h->engine) return -2;

#if NV_TENSORRT_MAJOR >= 10
    int n = static_cast<int>(h->engine->getNbIOTensors());
    if (index < 0 || index >= n) return -3;
    const char* name = h->engine->getIOTensorName(index);
    if (!name) return -4;
    auto mode = h->engine->getTensorIOMode(name);
    return (mode == nvinfer1::TensorIOMode::kINPUT) ? 1 : 0;
#else
    int n = static_cast<int>(h->engine->getNbBindings());
    if (index < 0 || index >= n) return -3;
    return h->engine->bindingIsInput(index) ? 1 : 0;
#endif
}

SMARTSEG_API int SmartSegGetTensorDims(void* handle, int index, int* dims, int max)
{
    if (!handle || !dims || max <= 0) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (!h->engine) return -2;

#if NV_TENSORRT_MAJOR >= 10
    int n = static_cast<int>(h->engine->getNbIOTensors());
    if (index < 0 || index >= n) return -3;
    const char* name = h->engine->getIOTensorName(index);
    if (!name) return -4;
    nvinfer1::Dims d = h->engine->getTensorShape(name);
#else
    int n = static_cast<int>(h->engine->getNbBindings());
    if (index < 0 || index >= n) return -3;
    nvinfer1::Dims d = h->engine->getBindingDimensions(index);
#endif

    int ndim = d.nbDims;
    if (ndim > max) ndim = max; // 잘림 허용
    for (int i = 0; i < ndim; ++i) dims[i] = d.d[i];
    return d.nbDims; // 실제 차원수(잘렸을 수 있음)
}

// 유틸: HWC BGR8 -> NCHW FP32 [0..1] (resize 없음, 정확히 640x640 가정)
static void hwc_bgr8_to_nchw_fp32(const unsigned char* src, int w, int h, int strideBytes, float* dst /*3*H*W*/)
{
    // dst: [C,H,W] = [3,h,w], channel order = RGB
    const int HW = w * h;
    float* dstR = dst + 0 * HW;
    float* dstG = dst + 1 * HW;
    float* dstB = dst + 2 * HW;

    for (int y = 0; y < h; ++y)
    {
        const unsigned char* row = src + y * strideBytes;
        for (int x = 0; x < w; ++x)
        {
            const unsigned char* p = row + x * 3;
            // B, G, R (Windows)
            float b = p[0] * (1.0f / 255.0f);
            float g = p[1] * (1.0f / 255.0f);
            float r = p[2] * (1.0f / 255.0f);

            int idx = y * w + x;
            dstR[idx] = r;
            dstG[idx] = g;
            dstB[idx] = b;
        }
    }
}

SMARTSEG_API int SmartSegGetNumOutputs(void* handle) {
    if (!handle) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    return static_cast<int>(h->lastOutputs.size());
}

SMARTSEG_API int SmartSegGetOutputName(void* handle, int idx, char* out, int max) {
    if (!handle || !out || max <= 0) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (idx < 0 || idx >= (int)h->lastOutputs.size()) return -2;
    auto& s = h->lastOutputs[idx].name;
    int len = (int)std::min<size_t>(s.size(), max - 1);
    std::memcpy(out, s.data(), len); out[len] = '\0';
    return len;
}

SMARTSEG_API int SmartSegGetOutputDims(void* handle, int idx, int* dims, int max) {
    if (!handle || !dims || max <= 0) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (idx < 0 || idx >= (int)h->lastOutputs.size()) return -2;
    auto d = h->lastOutputs[idx].dims;
    int n = std::min(max, d.nbDims);
    for (int i = 0; i < n; ++i) dims[i] = d.d[i];
    return d.nbDims;
}

SMARTSEG_API int SmartSegGetOutputFloat(void* handle, int idx, float* dst, int maxFloats) {
    if (!handle || !dst || maxFloats <= 0) return -1;
    auto* h = reinterpret_cast<TrtHandle*>(handle);
    if (idx < 0 || idx >= (int)h->lastOutputs.size()) return -2;
    const auto& buf = h->lastOutputs[idx].data;
    int n = (int)std::min<size_t>(buf.size(), maxFloats);
    std::memcpy(dst, buf.data(), n * sizeof(float));
    return n; // 복사한 float 개수
}

// 버퍼 크기 계산
static size_t volume_of_dims(const nvinfer1::Dims& d)
{
    size_t v = 1;
    for (int i = 0; i < d.nbDims; ++i)
    {
        int s = (std::max)(1, (int)d.d[i]);  // 괄호 트릭 + 캐스팅
        v *= static_cast<size_t>(s);
    }
    return v;
}

SMARTSEG_API int SmartSegInfer(void* handle,
    const unsigned char* bgr, int w, int h, int strideBytes)
{
    if (!handle) return -1;
    auto* hdl = reinterpret_cast<TrtHandle*>(handle);
    if (!hdl->engine || !hdl->context || !hdl->stream) return -2;
    if (!bgr) return -3;

    // 결과 초기화
    hdl->lastOutputs.clear();

#if NV_TENSORRT_MAJOR >= 10
    const int nIO = static_cast<int>(hdl->engine->getNbIOTensors());
    const char* inputName = nullptr;
    for (int i = 0; i < nIO; ++i) {
        const char* nm = hdl->engine->getIOTensorName(i);
        if (hdl->engine->getTensorIOMode(nm) == nvinfer1::TensorIOMode::kINPUT) { inputName = nm; break; }
    }
    if (!inputName) return -4;

    // 입력: 1x3x640x640 고정
    const int inN = 1, inC = 3, inH = 640, inW = 640;
    if (w != inW || h != inH) {
        std::printf("[SmartSegTRT] ERROR: only %dx%d supported at the moment. got %dx%d\n", inW, inH, w, h);
        return -10;
    }
    nvinfer1::Dims inShape{ 4, {inN, inC, inH, inW} };
    if (!hdl->context->setInputShape(inputName, inShape)) {
        std::printf("[SmartSegTRT] setInputShape failed\n");
        return -5;
    }
#else
    const int nIO = static_cast<int>(hdl->engine->getNbBindings());
    int inputIndex = -1;
    for (int i = 0; i < nIO; ++i) if (hdl->engine->bindingIsInput(i)) { inputIndex = i; break; }
    if (inputIndex < 0) return -4;

    const int inN = 1, inC = 3, inH = 640, inW = 640;
    if (w != inW || h != inH) {
        std::printf("[SmartSegTRT] ERROR: only %dx%d supported at the moment. got %dx%d\n", inW, inH, w, h);
        return -10;
    }
    nvinfer1::Dims4 inShape(inN, inC, inH, inW);
    if (!hdl->context->setBindingDimensions(inputIndex, inShape)) {
        std::printf("[SmartSegTRT] setBindingDimensions failed\n");
        return -5;
    }
#endif

    // CPU 전처리 (BGR8 → NCHW FP32)
    const size_t inElems = static_cast<size_t>(inN) * inC * inH * inW;
    std::vector<float> hostInput(inElems);
    hwc_bgr8_to_nchw_fp32(bgr, inW, inH, strideBytes, hostInput.data());

    // GPU 버퍼
    void* dInput = nullptr;
    if (cudaSuccess != cudaMalloc(&dInput, inElems * sizeof(float))) return -20;
    cudaMemcpyAsync(dInput, hostInput.data(), inElems * sizeof(float), cudaMemcpyHostToDevice, hdl->stream);

    std::vector<void*> outputsDev;

#if NV_TENSORRT_MAJOR >= 10
    // v10: setTensorAddress
    for (int i = 0; i < nIO; ++i)
    {
        const char* nm = hdl->engine->getIOTensorName(i);
        if (hdl->engine->getTensorIOMode(nm) == nvinfer1::TensorIOMode::kOUTPUT)
        {
            // 실제 런타임 shape는 context에서
            nvinfer1::Dims d = hdl->context->getTensorShape(nm);
            size_t elems = volume_of_dims(d);
            size_t bytes = elems * sizeof(float); // FP32 가정

            void* dOut = nullptr;
            if (cudaSuccess != cudaMalloc(&dOut, bytes)) { cudaFree(dInput); return -21; }
            outputsDev.push_back(dOut);
            hdl->context->setTensorAddress(nm, dOut);

            HostTensor ht;
            ht.name = nm;
            ht.dims = d;
            ht.data.resize(elems);
            hdl->lastOutputs.emplace_back(std::move(ht));
        }
        else {
            if (std::strcmp(nm, inputName) == 0)
                hdl->context->setTensorAddress(nm, dInput);
        }
    }

    // 실행
    bool ok = hdl->context->enqueueV3(hdl->stream);
#else
    // v9: bindings 사용
    std::vector<void*> bindings(nIO, nullptr);
    bindings[inputIndex] = dInput;

    for (int i = 0; i < nIO; ++i)
    {
        if (!hdl->engine->bindingIsInput(i))
        {
            nvinfer1::Dims d = hdl->engine->getBindingDimensions(i);
            size_t elems = volume_of_dims(d);
            size_t bytes = elems * sizeof(float);

            void* dOut = nullptr;
            if (cudaSuccess != cudaMalloc(&dOut, bytes)) { cudaFree(dInput); return -21; }
            outputsDev.push_back(dOut);
            bindings[i] = dOut;

            HostTensor ht;
            const char* nm = hdl->engine->getBindingName(i);
            ht.name = nm ? nm : std::string();
            ht.dims = d;
            ht.data.resize(elems);
            hdl->lastOutputs.emplace_back(std::move(ht));
        }
    }

    bool ok = hdl->context->enqueueV2(bindings.data(), hdl->stream, nullptr);
#endif

    if (!ok) {
        std::printf("[SmartSegTRT] enqueue failed\n");
        for (void* p : outputsDev) cudaFree(p);
        cudaFree(dInput);
        hdl->lastOutputs.clear();
        return -6;
    }

    // D2H 복사
    for (size_t k = 0; k < outputsDev.size(); ++k) {
        auto& ht = hdl->lastOutputs[k];
        cudaMemcpyAsync(ht.data.data(), outputsDev[k],
            ht.data.size() * sizeof(float),
            cudaMemcpyDeviceToHost, hdl->stream);
    }
    cudaStreamSynchronize(hdl->stream);

    // 정리
    for (void* p : outputsDev) cudaFree(p);
    cudaFree(dInput);
    return 0;
}

