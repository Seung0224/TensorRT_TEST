﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmartSegTRT_TEST
{
    public partial class MainForm : Form
    {
        private static class SmartSegTRTNative
        {
            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
            public static extern IntPtr SmartSegCreate(string enginePath);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern void SmartSegDestroy(IntPtr handle);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegGetNbIOTensors(IntPtr handle);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
            public static extern int SmartSegGetTensorName(IntPtr handle, int index, StringBuilder outName, int maxLen);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegIsInput(IntPtr handle, int index);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegGetTensorDims(IntPtr handle, int index, int[] dims, int max); // 반환값=ndim(실제)

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegInfer(IntPtr handle, IntPtr bgr, int width, int height, int strideBytes);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegGetNumOutputs(IntPtr handle);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
            public static extern int SmartSegGetOutputName(IntPtr handle, int outIndex, StringBuilder outName, int maxLen);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegGetOutputDims(IntPtr handle, int outIndex, int[] dims, int max);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegGetOutputFloat(IntPtr handle, int outIndex, float[] dst, int maxFloats);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegDecode(IntPtr handle, float confThres, float iouThres, int topK);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegGetNumDetections(IntPtr handle);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegGetDetBox(IntPtr handle, int idx, float[] xyxy4);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern float SmartSegGetDetScore(IntPtr handle, int idx);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegGetDetClass(IntPtr handle, int idx);

            [DllImport("SmartSegTRT.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SmartSegGetDetMask(IntPtr handle, int idx, IntPtr dst, int outW, int outH, int dstStride, float thresh);
        }

        private struct LetterboxInfo
        {
            public int padX, padY;   // 640 프레임 내 좌우/상하 패딩
            public float scale;      // 원본→640로 갈 때의 스케일 (min(640/w, 640/h))
        }

        private Button btnInfer;
        private Button btnOverlay;
        private Button btnPickAndTest;
        private TextBox txtLog;

        public MainForm()
        {
            InitializeComponent();

            Text = "SmartSegTRT Smoke Test (.NET Framework 4.8.1)";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(720, 420);

            btnPickAndTest = new Button
            {
                Text = "엔진 선택 후 로드/파괴 테스트",
                AutoSize = true,
                Location = new Point(12, 12)
            };
            btnPickAndTest.Click += BtnPickAndTest_Click;

            btnInfer = new Button
            {
                Text = "엔진+이미지 선택 후 Infer 실행",
                AutoSize = true,
                Location = new Point(240, 12)   // 위치는 취향껏 조정
            };
            btnInfer.Click += BtnInfer_Click;

            Controls.Add(btnInfer);
            btnOverlay = new Button
            {
                Text = "Infer + Decode + Overlay",
                AutoSize = true,
                Location = new Point(480, 12) // 위치는 취향껏
            };
            btnOverlay.Click += BtnOverlay_Click;
            Controls.Add(btnOverlay);


            txtLog = new TextBox
            {
                Multiline = true,
                ScrollBars = ScrollBars.Both,
                WordWrap = false,
                Location = new Point(12, 50),
                Size = new Size(690, 350),
                Font = new Font("Consolas", 10f)
            };

            Controls.Add(btnPickAndTest);
            Controls.Add(txtLog);
        }


        private static Bitmap MakeLetterbox640(Bitmap src, out LetterboxInfo info)
        {
            const int dst = 640;
            float r = Math.Min((float)dst / src.Width, (float)dst / src.Height);
            int newW = (int)Math.Round(src.Width * r);
            int newH = (int)Math.Round(src.Height * r);
            int padX = (dst - newW) / 2;
            int padY = (dst - newH) / 2;

            var dstBmp = new Bitmap(dst, dst, PixelFormat.Format24bppRgb);
            using (var g = Graphics.FromImage(dstBmp))
            {
                g.Clear(Color.FromArgb(114, 114, 114));   // YOLO 기본 패딩색
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.CompositingQuality = CompositingQuality.HighQuality;
                g.DrawImage(src, new Rectangle(padX, padY, newW, newH));
            }

            info = new LetterboxInfo { padX = padX, padY = padY, scale = r };
            return dstBmp;
        }

        private static void MapMaskToOriginal(byte[] mask640, int w640, int h640,
                                      byte[] dstMask, int w, int h, LetterboxInfo lb)
        {
            for (int y = 0; y < h; y++)
            {
                int sy = (int)Math.Round(y * lb.scale + lb.padY);
                sy = Math.Max(0, Math.Min(h640 - 1, sy));
                for (int x = 0; x < w; x++)
                {
                    int sx = (int)Math.Round(x * lb.scale + lb.padX);
                    sx = Math.Max(0, Math.Min(w640 - 1, sx));
                    dstMask[y * w + x] = mask640[sy * w640 + sx];
                }
            }
        }

        private static void OverlayMaskInPlace(Bitmap dst, byte[] mask, Color color, byte alpha)
        {
            var rect = new Rectangle(0, 0, dst.Width, dst.Height);
            var data = dst.LockBits(rect, ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
            try
            {
                int w = dst.Width, h = dst.Height, stride = data.Stride;
                var buf = new byte[stride * h];
                Marshal.Copy(data.Scan0, buf, 0, buf.Length);

                float a = alpha / 255f;
                for (int y = 0; y < h; y++)
                {
                    int mOfs = y * w;
                    int pOfs = y * stride;
                    for (int x = 0; x < w; x++)
                    {
                        if (mask[mOfs + x] == 0) continue;
                        int idx = pOfs + x * 4; // BGRA
                        buf[idx + 0] = (byte)(buf[idx + 0] * (1 - a) + color.B * a);
                        buf[idx + 1] = (byte)(buf[idx + 1] * (1 - a) + color.G * a);
                        buf[idx + 2] = (byte)(buf[idx + 2] * (1 - a) + color.R * a);
                        buf[idx + 3] = 255;
                    }
                }
                Marshal.Copy(buf, 0, data.Scan0, buf.Length);
            }
            finally { dst.UnlockBits(data); }
        }



        private void BtnOverlay_Click(object sender, EventArgs e)
        {
            // 1) 엔진 선택
            string enginePath;
            using (var ofd = new OpenFileDialog
            {
                Title = "Select TensorRT Engine (.engine)",
                Filter = "TensorRT Engine (*.engine)|*.engine|All Files (*.*)|*.*"
            })
            {
                if (ofd.ShowDialog(this) != DialogResult.OK) return;
                enginePath = ofd.FileName;
            }

            // 2) 이미지 선택
            string imagePath;
            using (var ofd = new OpenFileDialog
            {
                Title = "Select Image",
                Filter = "Image Files (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp|All Files (*.*)|*.*"
            })
            {
                if (ofd.ShowDialog(this) != DialogResult.OK) return;
                imagePath = ofd.FileName;
            }

            // 3) 실행 & 프리뷰
            using (var result = RunInferDecodeOverlay(enginePath, imagePath))
            {
                if (result == null) { Log("결과 이미지 없음."); return; }
                using (var dlg = new Form { Text = "Overlay Preview", ClientSize = new Size(700, 720), StartPosition = FormStartPosition.CenterParent })
                using (var pb = new PictureBox { Dock = DockStyle.Fill, SizeMode = PictureBoxSizeMode.Zoom, Image = (Bitmap)result.Clone() })
                {
                    dlg.Controls.Add(pb);
                    dlg.ShowDialog(this);
                }
            }
        }

        private Bitmap RunInferDecodeOverlay(string enginePath, string imagePath)
        {
            IntPtr h = IntPtr.Zero;
            try
            {
                h = SmartSegTRTNative.SmartSegCreate(enginePath);
                if (h == IntPtr.Zero) { Log("Create failed."); return null; }

                using (var orig = (Bitmap)Image.FromFile(imagePath))  // 원본 유지
                {
                    // (1) 레터박스 입력 생성
                    LetterboxInfo lb;
                    using (var inp = MakeLetterbox640(orig, out lb))   // 640×640/24bpp
                    {
                        // (2) Infer
                        var rect = new Rectangle(0, 0, inp.Width, inp.Height);
                        var data = inp.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
                        int ret;
                        try
                        {
                            ret = SmartSegTRTNative.SmartSegInfer(h, data.Scan0, inp.Width, inp.Height, Math.Abs(data.Stride));
                        }
                        finally { inp.UnlockBits(data); }
                        Log($"Infer ret = {ret}");
                        if (ret != 0) return null;
                    }

                    // (3) Decode (임계값은 상황 따라 조정)
                    int nDet = SmartSegTRTNative.SmartSegDecode(h, 0.45f, 0.50f, 20);
                    Log($"Decode: nDet = {nDet}");

                    var result = new Bitmap(orig.Width, orig.Height, PixelFormat.Format32bppArgb);
                    using (var g0 = Graphics.FromImage(result)) g0.DrawImage(orig, 0, 0);

                    if (nDet <= 0) return result;

                    var colors = new[]
                    {
                Color.FromArgb(50,205, 50), Color.FromArgb(255,165, 0),
                Color.FromArgb(30,144,255), Color.FromArgb(255, 99,71),
                Color.FromArgb(186, 85,211)
            };

                    for (int i = 0; i < Math.Min(nDet, 10); i++)
                    {
                        // 3-1) 640 기준 마스크 취득
                        int W = 640, H = 640;
                        var mask640 = new byte[W * H];
                        IntPtr buf = Marshal.AllocHGlobal(mask640.Length);
                        try
                        {
                            int ok = SmartSegTRTNative.SmartSegGetDetMask(h, i, buf, W, H, W, 0.5f);
                            if (ok != 0) continue;
                            Marshal.Copy(buf, mask640, 0, mask640.Length);
                        }
                        finally { Marshal.FreeHGlobal(buf); }

                        // 3-2) 원본으로 역사상
                        var maskOrig = new byte[orig.Width * orig.Height];
                        MapMaskToOriginal(mask640, 640, 640, maskOrig, orig.Width, orig.Height, lb);
                        OverlayMaskInPlace(result, maskOrig, colors[i % colors.Length], 96);

                        // 3-3) 박스도 원본 좌표로 역사상해 그리기
                        var box = new float[4];
                        SmartSegTRTNative.SmartSegGetDetBox(h, i, box);
                        float score = SmartSegTRTNative.SmartSegGetDetScore(h, i);

                        float ox1 = (box[0] - lb.padX) / lb.scale;
                        float oy1 = (box[1] - lb.padY) / lb.scale;
                        float ox2 = (box[2] - lb.padX) / lb.scale;
                        float oy2 = (box[3] - lb.padY) / lb.scale;

                        ox1 = ClampF(ox1, 0f, orig.Width - 1f);
                        oy1 = ClampF(oy1, 0f, orig.Height - 1f);
                        ox2 = ClampF(ox2, 0f, orig.Width - 1f);
                        oy2 = ClampF(oy2, 0f, orig.Height - 1f);

                        using (var g = Graphics.FromImage(result))
                        using (var pen = new Pen(colors[i % colors.Length], 2))
                        using (var f = new Font("Segoe UI", 10f, FontStyle.Bold))
                        using (var br = new SolidBrush(Color.FromArgb(200, 0, 0, 0)))
                        using (var fr = new SolidBrush(Color.White))
                        {
                            g.SmoothingMode = SmoothingMode.HighQuality;
                            g.DrawRectangle(pen, ox1, oy1, ox2 - ox1, oy2 - oy1);

                            var label = $"cls0 {score:0.00}";
                            var sz = g.MeasureString(label, f);
                            var r = new RectangleF(ox1, Math.Max(0, oy1 - sz.Height), sz.Width + 6, sz.Height);
                            g.FillRectangle(br, r);
                            g.DrawString(label, f, fr, r.X + 3, r.Y);
                        }
                    }
                    return result;
                }
            }
            catch (Exception ex)
            {
                Log(ex.ToString());
                return null;
            }
            finally
            {
                if (h != IntPtr.Zero) SmartSegTRTNative.SmartSegDestroy(h);
            }
        }

        private static float ClampF(float v, float lo, float hi)
        => v < lo ? lo : (v > hi ? hi : v);

        private void Log(string s) => txtLog.AppendText($"[{DateTime.Now:HH:mm:ss.fff}] {s}{Environment.NewLine}");

        private void BtnPickAndTest_Click(object sender, EventArgs e)
        {
            using (var ofd = new OpenFileDialog()
            {
                Title = "Select TensorRT Engine (.engine)",
                Filter = "TensorRT Engine (*.engine)|*.engine|All Files (*.*)|*.*"
            })
            {
                if (ofd.ShowDialog(this) != DialogResult.OK)
                    return;

                string enginePath = ofd.FileName;
                RunListBindings(enginePath);
            }
        }
        private void BtnInfer_Click(object sender, EventArgs e)
        {
            // 1) 엔진 선택
            string enginePath = null;
            using (var ofd = new OpenFileDialog
            {
                Title = "Select TensorRT Engine (.engine)",
                Filter = "TensorRT Engine (*.engine)|*.engine|All Files (*.*)|*.*"
            })
            {
                if (ofd.ShowDialog(this) != DialogResult.OK) return;
                enginePath = ofd.FileName;
            }

            // 2) 이미지 선택
            string imagePath = null;
            using (var ofd = new OpenFileDialog
            {
                Title = "Select Image (640x640, BGR)",
                Filter = "Image Files (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp|All Files (*.*)|*.*"
            })
            {
                if (ofd.ShowDialog(this) != DialogResult.OK) return;
                imagePath = ofd.FileName;
            }

            // 3) 실행
            Log($"Infer 실행 - engine: {enginePath}, image: {imagePath}");
            RunInferOnce(enginePath, imagePath);
        }


        private void RunInferOnce(string enginePath, string imagePath)
        {
            IntPtr h = IntPtr.Zero;
            try
            {
                h = SmartSegTRTNative.SmartSegCreate(enginePath);
                if (h == IntPtr.Zero) { Log("Create failed."); return; }

                using (var orig = (Bitmap)Image.FromFile(imagePath))
                using (var bmp = MakeInput640(orig)) // 640×640 / 24bppRgb 보장
                {
                    var rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
                    var data = bmp.LockBits(rect,
                        System.Drawing.Imaging.ImageLockMode.ReadOnly,
                        System.Drawing.Imaging.PixelFormat.Format24bppRgb);

                    try
                    {
                        int stride = Math.Abs(data.Stride);

                        var sw = System.Diagnostics.Stopwatch.StartNew();
                        int ret = SmartSegTRTNative.SmartSegInfer(h, data.Scan0, bmp.Width, bmp.Height, stride);
                        sw.Stop();

                        Log($"Infer ret = {ret} (elapsed: {sw.ElapsedMilliseconds} ms)");

                        // ===== (선택) 마지막 출력 덤프 =====
                        // 아래 4개의 P/Invoke가 프로젝트에 추가되어 있다면 출력 정보를 로그로 확인.
                        // 없으면 자동으로 건너뜁니다.
                        //   SmartSegGetNumOutputs, SmartSegGetOutputName,
                        //   SmartSegGetOutputDims, SmartSegGetOutputFloat
                        try
                        {
                            int numOut = SmartSegTRTNative.SmartSegGetNumOutputs(h);
                            Log($"num outputs = {numOut}");

                            for (int i = 0; i < numOut; i++)
                            {
                                var name = new StringBuilder(128);
                                SmartSegTRTNative.SmartSegGetOutputName(h, i, name, name.Capacity);

                                int[] dims = new int[8];
                                int ndim = SmartSegTRTNative.SmartSegGetOutputDims(h, i, dims, dims.Length);
                                int elems = dims.Take(Math.Min(ndim, dims.Length))
                                                .Aggregate(1, (a, b) => a * (b < 1 ? 1 : b));

                                int toCopy = Math.Min(elems, 16);
                                var buf = new float[toCopy];
                                int copied = SmartSegTRTNative.SmartSegGetOutputFloat(h, i, buf, buf.Length);

                                string shape = (ndim > 0) ? string.Join("x", dims.Take(ndim)) : "<?>";

                                Log($"out[{i}] {name} shape={shape}, elems={elems}, copied={copied}, head={string.Join(", ", buf.Select(v => v.ToString("0.000")))}");
                            }
                        }
                        catch (EntryPointNotFoundException)
                        {
                            // 최신 출력 API가 아직 DLL에 없는 경우엔 조용히 스킵
                            Log("출력 조회 API가 없어 덤프를 생략합니다 (SmartSegGet*Output* 미정의).");
                        }

                        // 1) Decode
                        int nDet = SmartSegTRTNative.SmartSegDecode(h, confThres: 0.25f, iouThres: 0.45f, topK: 50);
                        Log($"Decode: nDet = {nDet}");

                        for (int i = 0; i < nDet; i++)
                        {
                            var box = new float[4];
                            SmartSegTRTNative.SmartSegGetDetBox(h, i, box);
                            float score = SmartSegTRTNative.SmartSegGetDetScore(h, i);
                            int cls = SmartSegTRTNative.SmartSegGetDetClass(h, i);
                            Log($"[{i}] cls={cls} score={score:0.000} box=({box[0]:0.0},{box[1]:0.0},{box[2]:0.0},{box[3]:0.0})");

                            // 2) 마스크 640x640 받아보기 (바이너리 0/255)
                            int W = 640, H = 640;
                            IntPtr buf = IntPtr.Zero;
                            try
                            {
                                buf = Marshal.AllocHGlobal(W * H);
                                int ok = SmartSegTRTNative.SmartSegGetDetMask(h, i, buf, W, H, W, 0.5f);
                                Log($"    mask get = {ok}");

                                // 필요하면 여기서 buf → byte[] 복사해서 Heat/Overlay 생성
                                // var managed = new byte[W*H];
                                // Marshal.Copy(buf, managed, 0, managed.Length);
                            }
                            finally
                            {
                                if (buf != IntPtr.Zero) Marshal.FreeHGlobal(buf);
                            }
                        }
                    }
                    finally
                    {
                        bmp.UnlockBits(data);
                    }
                }
            }
            catch (Exception ex)
            {
                Log(ex.ToString());
            }
            finally
            {
                if (h != IntPtr.Zero) SmartSegTRTNative.SmartSegDestroy(h);
            }
        }




        private void RunListBindings(string enginePath)
        {
            IntPtr h = IntPtr.Zero;
            try
            {
                Log($"Load: {enginePath}");
                h = SmartSegTRTNative.SmartSegCreate(enginePath);
                if (h == IntPtr.Zero) { Log("Create failed."); return; }

                int n = SmartSegTRTNative.SmartSegGetNbIOTensors(h);
                Log($"NbIOTensors = {n}");

                for (int i = 0; i < n; i++)
                {
                    var sb = new StringBuilder(256);
                    int copied = SmartSegTRTNative.SmartSegGetTensorName(h, i, sb, sb.Capacity);
                    string name = (copied > 0) ? sb.ToString() : $"<idx:{i}>";

                    int isInput = SmartSegTRTNative.SmartSegIsInput(h, i);

                    int[] dims = new int[16];
                    int ndim = SmartSegTRTNative.SmartSegGetTensorDims(h, i, dims, dims.Length);

                    string shape = (ndim > 0)
                        ? string.Join("x", dims.Take(Math.Min(ndim, dims.Length)))
                        : "<?>";

                    Log($"[{i}] {(isInput == 1 ? "INPUT " : "OUTPUT")}  {name}  shape={shape}");
                }
            }
            catch (Exception ex)
            {
                Log(ex.ToString());
            }
            finally
            {
                if (h != IntPtr.Zero) SmartSegTRTNative.SmartSegDestroy(h);
                Log("Destroyed.");
            }
        }

        private static Bitmap MakeInput640(Bitmap src)
        {
            // 이미 640×640/24bpp면 그대로 복사해서 반환
            if (src.Width == 640 && src.Height == 640 && src.PixelFormat == PixelFormat.Format24bppRgb)
                return (Bitmap)src.Clone();

            var dst = new Bitmap(640, 640, PixelFormat.Format24bppRgb);
            using (var g = Graphics.FromImage(dst))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.CompositingQuality = CompositingQuality.HighQuality;
                g.SmoothingMode = SmoothingMode.None;
                g.DrawImage(src, new Rectangle(0, 0, 640, 640));
            }
            return dst;
        }
    }
}
