﻿// TensorRTRunner.cpp  (TensorRT 10.x 호환)
// Build: DLL (Release x64), C++17
// Link: nvinfer.lib, cudart.lib  (플러그인 쓰면 nvinfer_plugin.lib)
// Runtime DLL: nvinfer.dll, cudart64_xx.dll 등이 exe 폴더 또는 PATH에 있어야 함.

#include "pch.h"   // ⚠️ PCH 사용 프로젝트라면 반드시 맨 처음에!
#include <NvInfer.h>
#include <cuda_runtime_api.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <memory>
#include <mutex>
#include <cmath>   // std::sqrt, std::lround

// ---- export macro (기존 DLLEXPORT 충돌 방지) ----
#ifndef TRUNNER_API
# ifdef _WIN32
#   define TRUNNER_API extern "C" __declspec(dllexport)
# else
#   define TRUNNER_API extern "C"
# endif
#endif

// --------- helpers ----------
static inline size_t vol(const nvinfer1::Dims& d) {
    size_t v = 1;
    for (int i = 0; i < d.nbDims; ++i) v *= (size_t)d.d[i];
    return v;
}
static inline bool ok(cudaError_t e) { return e == cudaSuccess; }

struct Logger : public nvinfer1::ILogger {
    void log(Severity s, const char* msg) noexcept override {
        if (s <= Severity::kWARNING) std::fprintf(stderr, "[TRT] %s\n", msg);
    }
} gLogger;

struct EngineHandle {
    nvinfer1::IRuntime* runtime = nullptr;
    nvinfer1::ICudaEngine* engine = nullptr;
    nvinfer1::IExecutionContext* ctx = nullptr;
    cudaStream_t                 stream = nullptr;

    // TRT10: 이름 기반 I/O
    std::string inputName;
    std::string detName;
    std::string protoName; // optional
};

static std::mutex gMtx;

// =============== API ===============

// 생성: .engine 로드
TRUNNER_API void* __cdecl trt_create_engine(const char* enginePath, int deviceId)
{
    if (!enginePath) return nullptr;
    std::lock_guard<std::mutex> lk(gMtx);

    cudaSetDevice(deviceId);

    // read engine file
    FILE* fp = nullptr;
#ifdef _WIN32
    fopen_s(&fp, enginePath, "rb");
#else
    fp = std::fopen(enginePath, "rb");
#endif
    if (!fp) return nullptr;
    std::fseek(fp, 0, SEEK_END);
    long sz = std::ftell(fp);
    std::fseek(fp, 0, SEEK_SET);
    std::vector<char> blob((size_t)sz);
    std::fread(blob.data(), 1, (size_t)sz, fp);
    std::fclose(fp);

    EngineHandle* H = new EngineHandle();

    H->runtime = nvinfer1::createInferRuntime(gLogger);
    if (!H->runtime) { delete H; return nullptr; }

    H->engine = H->runtime->deserializeCudaEngine(blob.data(), blob.size());
    if (!H->engine) { delete H->runtime; delete H; return nullptr; }

    H->ctx = H->engine->createExecutionContext();
    if (!H->ctx) { delete H->engine; delete H->runtime; delete H; return nullptr; }

    if (!ok(cudaStreamCreate(&H->stream))) {
        delete H->ctx; delete H->engine; delete H->runtime; delete H; return nullptr;
    }

    // TRT10: 이름 기반 I/O 조회
    int n = H->engine->getNbIOTensors();
    for (int i = 0; i < n; ++i) {
        const char* name = H->engine->getIOTensorName(i);
        auto mode = H->engine->getTensorIOMode(name);
        if (mode == nvinfer1::TensorIOMode::kINPUT) {
            H->inputName = name;
        }
        else {
            if (H->detName.empty()) H->detName = name;
            else if (H->protoName.empty()) H->protoName = name;
        }
    }
    return H;
}

// 파괴
TRUNNER_API void __cdecl trt_destroy_engine(void* h)
{
    if (!h) return;
    std::lock_guard<std::mutex> lk(gMtx);
    EngineHandle* H = (EngineHandle*)h;
    if (H->stream) cudaStreamDestroy(H->stream);
    // TRT10: destroy() 제거 → delete 사용
    delete H->ctx;
    delete H->engine;
    delete H->runtime;
    delete H;
}

// 입력 정사각 크기(알 수 없으면 0)
TRUNNER_API int __cdecl trt_get_input_size(void* h)
{
    if (!h) return 0;
    EngineHandle* H = (EngineHandle*)h;
    if (H->inputName.empty()) return 0;

    // 동적이면 -1이므로 의미 없음 → 0 반환
    nvinfer1::Dims d = H->engine->getTensorShape(H->inputName.c_str());
    if (d.nbDims == 4 && d.d[2] > 0 && d.d[3] > 0) return d.d[2];
    return 0;
}

// seg meta: 성공시 1 (proto 출력이 있을 때만)
TRUNNER_API int __cdecl trt_get_mask_meta(void* h, int* segDim, int* maskH, int* maskW)
{
    if (!h || !segDim || !maskH || !maskW) return 0;
    EngineHandle* H = (EngineHandle*)h;
    if (H->protoName.empty()) return 0;
    nvinfer1::Dims d = H->engine->getTensorShape(H->protoName.c_str());
    if (d.nbDims != 4) return 0;
    int C = d.d[1], Hh = d.d[2], Ww = d.d[3];
    if (C <= 0 || Hh <= 0 || Ww <= 0) return 0;
    *segDim = C; *maskH = Hh; *maskW = Ww;
    return 1;
}

// host float 메모리 (C#에서 trt_free로 해제)
static float* alloc_host(size_t n) { return (float*)std::malloc(n * sizeof(float)); }
TRUNNER_API void __cdecl trt_free(void* p) { if (p) std::free(p); }

// 추론
TRUNNER_API int __cdecl trt_infer(
    void* h,
    const float* nchw, int nchwLength,
    float** detOut, int* nDet, int* detC,
    float** protoOut, int* segDim, int* maskH, int* maskW)
{
    if (!h || !nchw || nchwLength <= 0 || !detOut || !nDet || !detC
        || !protoOut || !segDim || !maskH || !maskW) return 0;

    EngineHandle* H = (EngineHandle*)h;
    if (H->inputName.empty() || H->detName.empty()) return 0;

    // 입력 shape 설정 (NCHW = [1,3,net,net])
    int net = (int)std::lround(std::sqrt((double)nchwLength / 3.0));
    if (net <= 0) return 0;
    nvinfer1::Dims in;
    in.nbDims = 4; in.d[0] = 1; in.d[1] = 3; in.d[2] = net; in.d[3] = net;
    if (!H->ctx->setInputShape(H->inputName.c_str(), in)) return 0;

    // 입력 버퍼
    void* dIn = nullptr;
    size_t inBytes = (size_t)nchwLength * sizeof(float);
    if (cudaMalloc(&dIn, inBytes) != cudaSuccess) return 0;
    if (cudaMemcpyAsync(dIn, nchw, inBytes, cudaMemcpyHostToDevice, H->stream) != cudaSuccess) {
        cudaFree(dIn); return 0;
    }
    H->ctx->setTensorAddress(H->inputName.c_str(), dIn);

    // det 출력 shape (입력 shape 설정 후)
    nvinfer1::Dims detDims = H->ctx->getTensorShape(H->detName.c_str());
    size_t detElems = vol(detDims);
    if (detDims.nbDims == 3) { *nDet = detDims.d[1]; *detC = detDims.d[2]; }
    else if (detDims.nbDims == 2) { *nDet = detDims.d[0]; *detC = detDims.d[1]; }
    else { *nDet = (int)detElems; *detC = 1; }

    // det 디바이스 버퍼 (이름 충돌 방지: dDetBuf)
    void* dDetBuf = nullptr;
    size_t detBytes = detElems * sizeof(float);
    if (cudaMalloc(&dDetBuf, detBytes) != cudaSuccess) { cudaFree(dIn); return 0; }
    H->ctx->setTensorAddress(H->detName.c_str(), dDetBuf);

    // proto (선택)
    void* dProtoBuf = nullptr;
    size_t protoBytes = 0;
    int hasProto = 0;
    if (!H->protoName.empty()) {
        nvinfer1::Dims protoDims = H->ctx->getTensorShape(H->protoName.c_str());
        if (protoDims.nbDims == 4 && protoDims.d[1] > 0 && protoDims.d[2] > 0 && protoDims.d[3] > 0) {
            *segDim = protoDims.d[1];
            *maskH = protoDims.d[2];
            *maskW = protoDims.d[3];
            size_t pElems = vol(protoDims);
            protoBytes = pElems * sizeof(float);
            if (cudaMalloc(&dProtoBuf, protoBytes) != cudaSuccess) {
                cudaFree(dIn); cudaFree(dDetBuf); return 0;
            }
            H->ctx->setTensorAddress(H->protoName.c_str(), dProtoBuf);
            hasProto = 1;
        }
        else {
            *segDim = *maskH = *maskW = 0;
        }
    }
    else {
        *segDim = *maskH = *maskW = 0;
    }

    // 실행
    if (!H->ctx->enqueueV3(H->stream)) {
        cudaFree(dIn); cudaFree(dDetBuf); if (dProtoBuf) cudaFree(dProtoBuf);
        return 0;
    }

    // host 복사
    float* hDet = (float*)std::malloc(detBytes);
    if (!hDet) { cudaFree(dIn); cudaFree(dDetBuf); if (dProtoBuf) cudaFree(dProtoBuf); return 0; }
    if (cudaMemcpyAsync(hDet, dDetBuf, detBytes, cudaMemcpyDeviceToHost, H->stream) != cudaSuccess) {
        std::free(hDet); cudaFree(dIn); cudaFree(dDetBuf); if (dProtoBuf) cudaFree(dProtoBuf);
        return 0;
    }

    float* hProto = nullptr;
    if (hasProto) {
        hProto = (float*)std::malloc(protoBytes);
        if (!hProto) {
            std::free(hDet); cudaFree(dIn); cudaFree(dDetBuf); cudaFree(dProtoBuf); return 0;
        }
        if (cudaMemcpyAsync(hProto, dProtoBuf, protoBytes, cudaMemcpyDeviceToHost, H->stream) != cudaSuccess) {
            std::free(hDet); std::free(hProto);
            cudaFree(dIn); cudaFree(dDetBuf); cudaFree(dProtoBuf);
            return 0;
        }
    }

    cudaStreamSynchronize(H->stream);

    cudaFree(dIn);
    cudaFree(dDetBuf);
    if (dProtoBuf) cudaFree(dProtoBuf);

    *detOut = hDet;
    *protoOut = hProto; // 없을 수 있음(nullptr)
    return 1;
}
