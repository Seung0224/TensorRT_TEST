﻿// TensorRTRunner_fixed_win_trt10_pch.cpp
// If your project uses Precompiled Headers (PCH), keep this file's first include as "pch.h".
// If not, it's safe because we guard the include.

#include "pch.h"

#include <NvInfer.h>
#include <cuda_runtime.h>
#include <cuda_fp16.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <string>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <math.h>
#include <new>

// Export macro: avoid redefinition warnings
#if defined (_MSC_VER)
#ifndef TRT_API
#define TRT_API __declspec(dllexport)
#endif
#else
#ifndef TRT_API
#define TRT_API __attribute__((visibility("default")))
#endif
#endif

using namespace nvinfer1;

// ------------- Minimal ILogger -------------
class Logger : public ILogger {
public:
    void log(Severity severity, const char* msg) noexcept override {
        if (severity == Severity::kVERBOSE) return;
        const char* s =
            severity == Severity::kINTERNAL_ERROR ? "INTERNAL_ERROR" :
            severity == Severity::kERROR ? "ERROR" :
            severity == Severity::kWARNING ? "WARNING" :
            severity == Severity::kINFO ? "INFO" : "UNKNOWN";
        std::fprintf(stderr, "[TRT][%s] %s\n", s, msg ? msg : "");
    }
};
static Logger gLogger;

#define TRT_CHECK_RET0(call) do { \
    cudaError_t _e = (call); \
    if (_e != cudaSuccess) { \
        std::fprintf(stderr, "[TRT] CUDA error %s at %s:%d (%d)\n", cudaGetErrorString(_e), __FILE__, __LINE__, (int)_e); \
        return 0; \
    } \
} while(0)

#define TRT_CHECK_VOID(call) do { \
    cudaError_t _e = (call); \
    if (_e != cudaSuccess) { \
        std::fprintf(stderr, "[TRT] CUDA error %s at %s:%d (%d)\n", cudaGetErrorString(_e), __FILE__, __LINE__, (int)_e); \
        return; \
    } \
} while(0)

static size_t eltSize(DataType t) {
    switch (t) {
    case DataType::kFLOAT: return 4;
    case DataType::kHALF:  return 2;
    case DataType::kINT8:  return 1;
    case DataType::kINT32: return 4;
    case DataType::kBOOL:  return 1;
    default: return 4;
    }
}

static size_t vol(const nvinfer1::Dims& d) {
    size_t v = 1;
    for (int i = 0; i < d.nbDims; ++i) {
        int di = d.d[i];
        v *= static_cast<size_t>(di < 0 ? 1 : di);
    }
    return v;
}

static std::vector<char> readFile(const char* path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return {};
    f.seekg(0, std::ios::end);
    size_t sz = (size_t)f.tellg();
    f.seekg(0, std::ios::beg);
    std::vector<char> buf(sz);
    f.read(buf.data(), sz);
    return buf;
}

// Host conversions
static void floatToHalfHost(const float* src, __half* dst, size_t n) {
    for (size_t i = 0; i < n; ++i) dst[i] = __float2half(src[i]);
}
static void halfToFloatHost(const __half* src, float* dst, size_t n) {
    for (size_t i = 0; i < n; ++i) dst[i] = __half2float(src[i]);
}

// ------------- Engine handle -------------
struct EngineHandle {
    IRuntime* runtime = nullptr;
    ICudaEngine* engine = nullptr;
    IExecutionContext* ctx = nullptr;
    cudaStream_t stream = nullptr;
    int device = 0;

    std::string detName;
    std::string protoName;
    std::string inputName;
    DataType inputType = DataType::kFLOAT;
};

extern "C" {

    TRT_API void* trt_create_engine(const char* enginePath, int deviceId) {
        if (!enginePath) return nullptr;

        EngineHandle* H = new (std::nothrow) EngineHandle();
        if (!H) return nullptr;
        H->device = deviceId;

        if (cudaSetDevice(deviceId) != cudaSuccess) {
            std::fprintf(stderr, "[TRT] cudaSetDevice(%d) failed\n", deviceId);
            delete H;
            return nullptr;
        }

        std::vector<char> blob = readFile(enginePath);
        if (blob.empty()) {
            std::fprintf(stderr, "[TRT] Failed to read engine: %s\n", enginePath);
            delete H;
            return nullptr;
        }

        H->runtime = createInferRuntime(gLogger);
        if (!H->runtime) {
            std::fprintf(stderr, "[TRT] createInferRuntime failed\n");
            delete H;
            return nullptr;
        }

        H->engine = H->runtime->deserializeCudaEngine(blob.data(), blob.size());
        if (!H->engine) {
            std::fprintf(stderr, "[TRT] deserializeCudaEngine failed\n");
            delete H->runtime; H->runtime = nullptr;
            delete H;
            return nullptr;
        }

        H->ctx = H->engine->createExecutionContext();
        if (!H->ctx) {
            std::fprintf(stderr, "[TRT] createExecutionContext failed\n");
            delete H->engine;  H->engine = nullptr;
            delete H->runtime; H->runtime = nullptr;
            delete H;
            return nullptr;
        }

        if (cudaStreamCreate(&H->stream) != cudaSuccess) {
            std::fprintf(stderr, "[TRT] cudaStreamCreate failed\n");
            delete H->ctx;     H->ctx = nullptr;
            delete H->engine;  H->engine = nullptr;
            delete H->runtime; H->runtime = nullptr;
            delete H;
            return nullptr;
        }

        // First INPUT
        int nIO = H->engine->getNbIOTensors();
        for (int i = 0; i < nIO; ++i) {
            const char* tname = H->engine->getIOTensorName(i);
            if (H->engine->getTensorIOMode(tname) == TensorIOMode::kINPUT) {
                H->inputName = tname;
                H->inputType = H->engine->getTensorDataType(tname);
                break;
            }
        }

        // Heuristic output pick
        std::vector<std::string> outputs;
        for (int i = 0; i < nIO; ++i) {
            const char* tname = H->engine->getIOTensorName(i);
            if (H->engine->getTensorIOMode(tname) == TensorIOMode::kOUTPUT) outputs.emplace_back(tname);
        }
        auto hasName = [&](const char* key) {
            return std::find_if(outputs.begin(), outputs.end(), [&](const std::string& s) {
                return s.find(key) != std::string::npos;
                }) != outputs.end();
            };
        auto pickName = [&](const char* key) -> std::string {
            for (auto& s : outputs) if (s.find(key) != std::string::npos) return s;
            return outputs.empty() ? std::string() : outputs.front();
            };
        if (hasName("proto")) H->protoName = pickName("proto");
        if (hasName("mask") && H->protoName.empty()) H->protoName = pickName("mask");
        if (hasName("det")) H->detName = pickName("det");
        if (hasName("boxes") && H->detName.empty()) H->detName = pickName("boxes");
        if (H->detName.empty() && !outputs.empty()) H->detName = outputs.front();
        if (H->protoName.empty() && outputs.size() > 1) H->protoName = outputs.back();

        return (void*)H;
    }

    TRT_API void trt_destroy_engine(void* handle) {
        if (!handle) return;
        EngineHandle* H = (EngineHandle*)handle;
        cudaSetDevice(H->device);
        if (H->stream) { cudaStreamDestroy(H->stream); H->stream = nullptr; }
        if (H->ctx) { delete H->ctx;     H->ctx = nullptr; }
        if (H->engine) { delete H->engine;  H->engine = nullptr; }
        if (H->runtime) { delete H->runtime; H->runtime = nullptr; }
        delete H;
    }

    TRT_API int trt_get_input_size(void* handle) {
        if (!handle) return -1;
        EngineHandle* H = (EngineHandle*)handle;
        if (H->inputName.empty()) return -1;

        nvinfer1::Dims d = H->engine->getTensorShape(H->inputName.c_str());
        if (d.nbDims >= 4 && d.d[2] > 0 && d.d[3] > 0 && d.d[2] == d.d[3]) return d.d[2];
        return -1;
    }

    TRT_API int trt_get_mask_meta(void* handle, int* segDim, int* maskH, int* maskW) {
        if (!handle || !segDim || !maskH || !maskW) return 0;
        EngineHandle* H = (EngineHandle*)handle;
        if (H->protoName.empty()) return 0;
        nvinfer1::Dims d = H->ctx->getTensorShape(H->protoName.c_str());
        if (d.nbDims != 4) return 0;
        *segDim = (d.d[1] > 0 ? d.d[1] : 0);
        *maskH = (d.d[2] > 0 ? d.d[2] : 0);
        *maskW = (d.d[3] > 0 ? d.d[3] : 0);
        return 1;
    }

    TRT_API void trt_free(void* p) { if (p) std::free(p); }

    TRT_API int trt_infer(
        void* handle,
        const float* nchw, int nchwLength,
        float** detOut, int* nDet, int* detC,
        float** protoOut, int* segDim, int* maskH, int* maskW)
    {
        if (!handle || !nchw || nchwLength <= 0 || !detOut || !nDet || !detC || !protoOut || !segDim || !maskH || !maskW) return 0;
        EngineHandle* H = (EngineHandle*)handle;
        cudaSetDevice(H->device);

        // Deduce C,H,W (N=1)
        nvinfer1::Dims inD = H->engine->getTensorShape(H->inputName.c_str());
        int C = 0, Hh = 0, Ww = 0;
        if (inD.nbDims == 4) {
            C = (inD.d[1] > 0) ? inD.d[1] : 0;
            Hh = (inD.d[2] > 0) ? inD.d[2] : 0;
            Ww = (inD.d[3] > 0) ? inD.d[3] : 0;
        }
        if (C == 0) {
            if (nchwLength % 3 == 0) {
                C = 3;
                int hw = nchwLength / 3;
                int side = (int)(std::sqrt((double)hw) + 0.5);
                Hh = Ww = side;
            }
            else {
                C = 3;
                Hh = Ww = (int)(std::sqrt((double)nchwLength / 3.0) + 0.5);
            }
        }

        if (!H->ctx->setInputShape(H->inputName.c_str(), nvinfer1::Dims4(1, C, Hh, Ww))) {
            std::fprintf(stderr, "[TRT] setInputShape failed\n");
            return 0;
        }

        struct OutBuf {
            std::string name;
            nvinfer1::Dims shape;
            DataType dt;
            size_t bytes = 0;
            void* dptr = nullptr;
            bool wantHost = false;
        };
        std::vector<OutBuf> outs;
        int nIO = H->engine->getNbIOTensors();
        for (int i = 0; i < nIO; ++i) {
            const char* tname = H->engine->getIOTensorName(i);
            if (H->engine->getTensorIOMode(tname) == TensorIOMode::kOUTPUT) {
                OutBuf ob;
                ob.name = tname;
                ob.dt = H->engine->getTensorDataType(tname);
                ob.shape = H->ctx->getTensorShape(tname);
                size_t elems = vol(ob.shape);
                ob.bytes = elems * eltSize(ob.dt);
                if (ob.bytes == 0) {
                    std::fprintf(stderr, "[TRT] Output %s has zero size; shape may be unset\n", tname);
                    return 0;
                }
                TRT_CHECK_RET0(cudaMalloc(&ob.dptr, ob.bytes));
                ob.wantHost = (ob.name == H->detName) || (ob.name == H->protoName);
                outs.emplace_back(std::move(ob));
            }
        }
        if (outs.empty()) {
            std::fprintf(stderr, "[TRT] No outputs found\n");
            return 0;
        }

        // Input buffer
        DataType inType = H->engine->getTensorDataType(H->inputName.c_str());
        size_t inElems = (size_t)nchwLength;
        size_t inBytes = inElems * eltSize(inType);
        void* dIn = nullptr;
        TRT_CHECK_RET0(cudaMalloc(&dIn, inBytes));
        if (inType == DataType::kFLOAT) {
            TRT_CHECK_RET0(cudaMemcpyAsync(dIn, nchw, inBytes, cudaMemcpyHostToDevice, H->stream));
        }
        else if (inType == DataType::kHALF) {
            std::vector<__half> tmp(inElems);
            floatToHalfHost(nchw, tmp.data(), inElems);
            TRT_CHECK_RET0(cudaMemcpyAsync(dIn, tmp.data(), inBytes, cudaMemcpyHostToDevice, H->stream));
        }
        else if (inType == DataType::kINT8) {
            std::vector<int8_t> tmp(inElems);
            for (size_t i = 0; i < inElems; ++i) {
                float v = nchw[i];
                int iv = (int)std::round(v);
                iv = std::clamp(iv, -128, 127);
                tmp[i] = (int8_t)iv;
            }
            TRT_CHECK_RET0(cudaMemcpyAsync(dIn, tmp.data(), inBytes, cudaMemcpyHostToDevice, H->stream));
        }
        else {
            std::fprintf(stderr, "[TRT] Unsupported input dtype %d\n", (int)inType);
            cudaFree(dIn);
            for (auto& ob : outs) if (ob.dptr) cudaFree(ob.dptr);
            return 0;
        }

        if (!H->ctx->setTensorAddress(H->inputName.c_str(), dIn)) {
            std::fprintf(stderr, "[TRT] setTensorAddress(input) failed\n");
            cudaFree(dIn);
            for (auto& ob : outs) if (ob.dptr) cudaFree(ob.dptr);
            return 0;
        }
        for (auto& ob : outs) {
            if (!H->ctx->setTensorAddress(ob.name.c_str(), ob.dptr)) {
                std::fprintf(stderr, "[TRT] setTensorAddress(%s) failed\n", ob.name.c_str());
                cudaFree(dIn);
                for (auto& x : outs) if (x.dptr) cudaFree(x.dptr);
                return 0;
            }
        }

        if (!H->ctx->enqueueV3(H->stream)) {
            std::fprintf(stderr, "[TRT] enqueueV3 failed\n");
            cudaFree(dIn);
            for (auto& ob : outs) if (ob.dptr) cudaFree(ob.dptr);
            return 0;
        }
        TRT_CHECK_RET0(cudaStreamSynchronize(H->stream));

        *detOut = nullptr; *nDet = 0; *detC = 0;
        *protoOut = nullptr; *segDim = 0; *maskH = 0; *maskW = 0;

        auto exportToHostFloat = [&](const OutBuf& ob, float** outPtr) -> bool {
            size_t elems = vol(ob.shape);
            float* host = (float*)std::malloc(elems * sizeof(float));
            if (!host) return false;
            if (ob.dt == DataType::kFLOAT) {
                TRT_CHECK_RET0(cudaMemcpy(host, ob.dptr, elems * sizeof(float), cudaMemcpyDeviceToHost));
            }
            else if (ob.dt == DataType::kHALF) {
                std::vector<__half> tmp(elems);
                TRT_CHECK_RET0(cudaMemcpy(tmp.data(), ob.dptr, elems * sizeof(__half), cudaMemcpyDeviceToHost));
                halfToFloatHost(tmp.data(), host, elems);
            }
            else if (ob.dt == DataType::kINT8) {
                std::vector<int8_t> tmp(elems);
                TRT_CHECK_RET0(cudaMemcpy(tmp.data(), ob.dptr, elems * sizeof(int8_t), cudaMemcpyDeviceToHost));
                for (size_t i = 0; i < elems; ++i) host[i] = (float)tmp[i];
            }
            else if (ob.dt == DataType::kINT32) {
                std::vector<int32_t> tmp(elems);
                TRT_CHECK_RET0(cudaMemcpy(tmp.data(), ob.dptr, elems * sizeof(int32_t), cudaMemcpyDeviceToHost));
                for (size_t i = 0; i < elems; ++i) host[i] = (float)tmp[i];
            }
            else {
                std::free(host);
                return false;
            }
            *outPtr = host;
            return true;
            };

        for (auto& ob : outs) {
            if (!ob.wantHost) continue;
            if (ob.name == H->detName) {
                if (!exportToHostFloat(ob, detOut)) {
                    std::fprintf(stderr, "[TRT] det export failed\n");
                }
                else {
                    if (ob.shape.nbDims == 3) { *nDet = ob.shape.d[1]; *detC = ob.shape.d[2]; }
                    else if (ob.shape.nbDims == 2) { *nDet = ob.shape.d[0]; *detC = ob.shape.d[1]; }
                    else { *nDet = (int)vol(ob.shape); *detC = 1; }
                }
            }
            else if (ob.name == H->protoName) {
                if (!exportToHostFloat(ob, protoOut)) {
                    std::fprintf(stderr, "[TRT] proto export failed\n");
                }
                else {
                    if (ob.shape.nbDims == 4) {
                        *segDim = ob.shape.d[1];
                        *maskH = ob.shape.d[2];
                        *maskW = ob.shape.d[3];
                    }
                }
            }
        }

        cudaFree(dIn);
        for (auto& ob : outs) if (ob.dptr) cudaFree(ob.dptr);
        return (*detOut != nullptr || *protoOut != nullptr) ? 1 : 0;
    }

} // extern "C"
